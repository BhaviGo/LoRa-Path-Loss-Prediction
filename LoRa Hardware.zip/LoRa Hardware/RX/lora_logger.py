import serial
import requests
import time
import pandas as pd

# ----- SERIAL PORT -----
SERIAL_PORT = "COM7"   # change if needed
BAUD = 115200

# ----- LOCATION -----
LAT = "16.5280554"
LON = "80.5300752"

# dataset storage
data_log = []

# connect serial
ser = serial.Serial(SERIAL_PORT, BAUD, timeout=1)

print("Connected to FiPy")

def get_weather():

    try:

        url = (
            "http://api.open-meteo.com/v1/forecast"
            f"?latitude={LAT}&longitude={LON}"
            "&current=temperature_2m,wind_speed_10m,relative_humidity_2m"
        )

        response = requests.get(url)
        data = response.json()

        temp = data["current"]["temperature_2m"]
        humidity = data["current"]["relative_humidity_2m"]
        wind = data["current"]["wind_speed_10m"]

        return temp, humidity, wind

    except:
        return None, None, None


print("DIST | RSSI | SNR | PLOSS | TEMP | HUM | WIND | TX | SF | BW | CR")

while True:

    line = ser.readline().decode().strip()

    if line:

        values = line.split(",")

        dist, rssi, snr, ploss, tx, sf, bw, cr = values

        temp, hum, wind = get_weather()

        print(
            f"{dist} | {rssi} | {snr} | {ploss} | {temp} | {hum} | {wind} | {tx} | {sf} | {bw} | {cr}"
        )

        data_log.append([
            dist, rssi, snr, ploss, temp, hum, wind, tx, sf, bw, cr
        ])

        df = pd.DataFrame(data_log, columns=[
            "DIST","RSSI","SNR","PLOSS","TEMP","HUM","WIND","TX","SF","BW","CR"
        ])

        df.to_csv("lora_dataset.csv", index=False)

    time.sleep(0.1)