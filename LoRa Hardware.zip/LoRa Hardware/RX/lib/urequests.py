import usocket

class Response:
    def __init__(self, f):
        self.raw = f
        self.encoding = "utf-8"
        self._cached = None

    def close(self):
        if self.raw:
            self.raw.close()
            self.raw = None

    @property
    def content(self):
        if self._cached is None:
            try:
                self._cached = self.raw.read()
            finally:
                self.raw.close()
                self.raw = None
        return self._cached

    @property
    def text(self):
        return str(self.content, self.encoding)

    def json(self):
        import ujson
        return ujson.loads(self.content)

def get(url, **kw):
    try:
        proto, dummy, host, path = url.split("/", 3)
    except ValueError:
        proto, dummy, host = url.split("/", 2)
        path = ""
    port = 80
    if proto == "https:":
        import ussl
        port = 443
    if ":" in host:
        host, port = host.split(":", 1)
        port = int(port)
    
    ai = usocket.getaddrinfo(host, port, 0, usocket.SOCK_STREAM)
    ai = ai[0]
    s = usocket.socket(ai[0], ai[1], ai[2])
    try:
        s.connect(ai[-1])
        if proto == "https:":
            s = ussl.wrap_socket(s, server_hostname=host)
        s.write(b"GET /%s HTTP/1.0\r\n" % path)
        s.write(b"Host: %s\r\n\r\n" % host)
        l = s.readline()
        l = l.split(None, 2)
        status = int(l[1])
        while True:
            l = s.readline()
            if not l or l == b"\r\n":
                break
    except OSError:
        s.close()
        raise
    
    resp = Response(s)
    resp.status_code = status
    return resp