# main.py -- put your code here!
import network
from network import LoRa
import socket
import time
import pycom
import binascii

# 1. Setup LoRa (Region: India 865 MHz)
lora = LoRa(mode=LoRa.LORA, tx_power=14, region=LoRa.EU868, frequency=865062500)
lora.remove_channel(1)
lora.remove_channel(2)
lora.remove_channel(3)

# Get unique ID of this board
lora_mac = binascii.hexlify(network.LoRa().mac()).decode('utf8')

# 2. Create Socket
s = socket.socket(socket.AF_LORA, socket.SOCK_RAW)
s.setblocking(True)

# Turn off automatic heartbeat so we can control the LED
pycom.heartbeat(False)

print("LoRa Transmitter Started. Sending every 3 seconds...")

while True:
    # 3. Create Message
    msg = 'Msg from node ' + lora_mac
    
    # 4. Send Message
    s.send(msg)
    print('Sent:', msg)
    
    # 5. Blink LED (Yellow = Sending)
    pycom.rgbled(0x7f7f00) 
    time.sleep(0.1)
    pycom.rgbled(0x000000) # Off
    
    # 6. Wait before next send
    time.sleep(3)